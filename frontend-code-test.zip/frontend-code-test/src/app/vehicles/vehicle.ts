export interface Vehicle {
	id: string,
	name: string,
	modelYear: string
}
